﻿using PubnubApi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace MWCore.Areas.MWCore.Models.PubnubModules
{
    public class MWSubscribeCallback : SubscribeCallback
    {
        public override void Message<T>(Pubnub pubnub, PNMessageResult<T> message)
        {
            MWPubNubModel oModel = new JavaScriptSerializer().Deserialize<MWPubNubModel>(message.Message.ToString());
            oModel.LastUpdated = DateTime.Now;
            if (!MvcApplication.lstDriversCurrentLocations.Any(X => X.DriverID == oModel.DriverID))
            {
                MvcApplication.lstDriversCurrentLocations.Add(oModel);
            }
            else
            {
                MWPubNubModel oCurrentModel = MvcApplication.lstDriversCurrentLocations.Where(x => x.DriverID == oModel.DriverID).FirstOrDefault();
                MvcApplication.lstDriversCurrentLocations.Add(oCurrentModel);
                MvcApplication.lstDriversCurrentLocations.Add(oModel);
            }
        }

        public override void MessageAction(Pubnub pubnub, PNMessageActionEventResult messageAction)
        {
            throw new NotImplementedException();
        }

        public override void ObjectEvent(Pubnub pubnub, PNObjectApiEventResult objectEvent)
        {
            throw new NotImplementedException();
        }

        public override void Presence(Pubnub pubnub, PNPresenceEventResult presence)
        {
        }

        public override void Signal<T>(Pubnub pubnub, PNSignalResult<T> signal)
        {
            throw new NotImplementedException();
        }

        public override void Status(Pubnub pubnub, PNStatus status)
        {

        }
    }
    public class DemoPublishResult : PNCallback<PNPublishResult>
    {
        public override void OnResponse(PNPublishResult result, PNStatus status)
        {

        }
    }
}
