﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MWCore.Areas.MWCore.Models.PubnubModules
{
    public class MWPubNubModel
    {
        public int DriverID { get; set; }
        public double Lalatitude { get; set; }
        public double Longitude { get; set; }
        public DateTime LastUpdated { get; set; }
    }
}