﻿using PubnubApi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MWCore.Areas.MWCore.Models.Modules
{
    public class MWPublishResult : PNCallback<PNPublishResult>
    {
        public override void OnResponse(PNPublishResult result, PNStatus status)
        {
            
        }
    }
}