﻿using PubnubApi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MWCore.Areas.MWCore.Models.PubnubModules
{
    public class PubNubManager
    {
        public static Pubnub GeneratePubNubServer()
        {
            PNConfiguration pnConfiguration = new PNConfiguration();
            pnConfiguration.SubscribeKey = "sub-c-dcf8443a-2167-11ea-a548-4ab8a60a58c6";
            pnConfiguration.PublishKey = "pub-c-f33f1200-0528-410d-9f99-18098b329638";
            pnConfiguration.SecretKey = "sec-c-ZmM3ZDJhZjItM2QyNC00YWQ3LTk0MDMtNzUxNjc4OTM5MjEx";
            pnConfiguration.Uuid = "PubNubServerUser";
            Pubnub pubnub = new Pubnub(pnConfiguration);
            pubnub.AddListener(new MWSubscribeCallback());

            pubnub.Subscribe<string>()
                .Channels(new string[]{
            "PubNubServer"
                }).Execute();
            return pubnub;

        }
    }
}